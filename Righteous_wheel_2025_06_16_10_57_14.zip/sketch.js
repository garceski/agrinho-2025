let nuvens = [];

let carros = [];

function setup() {

  createCanvas(800, 600);

  // Inicializa algumas nuvens

  for (let i = 0; i < 3; i++) {

    nuvens.push({

      x: random(width),

      y: random(50, 150),

      largura: random(80, 150),

      altura: random(30, 60),

      velocidade: random(0.5, 1.5)

    });

  }

  // Inicializa alguns carros

  for (let i = 0; i < 4; i++) {

    carros.push({

      x: random(width),

      y: height - 100, // Na estrada

      largura: 50,

      altura: 25,

      velocidade: random(2, 4),

      cor: color(random(0, 255), random(0, 255), random(0, 255))

    });

  }

}

function draw() {

  // Cenário do Campo (dia)

  background(135, 206, 235); // Azul céu

  drawSol();

  drawNuvens();

  drawMontanhas();

  drawCampo();

  // Transição para a Cidade

  drawLinhaDoHorizonte();

  // Cenário da Cidade (noite/crepúsculo)

  drawPredios();

  drawEstrada();

  drawCarros();

  drawPostesDeLuz(); // Adiciona postes de luz

}

function drawSol() {

  fill(255, 204, 0); // Amarelo sol

  noStroke();

  ellipse(width * 0.15, height * 0.2, 80, 80);

}

function drawNuvens() {

  fill(255, 255, 255, 200); // Branco transparente

  noStroke();

  for (let nuvem of nuvens) {

    ellipse(nuvem.x, nuvem.y, nuvem.largura, nuvem.altura);

    ellipse(nuvem.x + nuvem.largura * 0.4, nuvem.y - nuvem.altura * 0.3, nuvem.largura * 0.6, nuvem.altura * 0.8);

    ellipse(nuvem.x - nuvem.largura * 0.3, nuvem.y + nuvem.altura * 0.2, nuvem.largura * 0.7, nuvem.altura * 0.7);

    // Move a nuvem

    nuvem.x += nuvem.velocidade;

    if (nuvem.x > width + nuvem.largura) {

      nuvem.x = -nuvem.largura;

      nuvem.y = random(50, 150);

    }

  }

}

function drawMontanhas() {

  fill(100, 150, 100); // Verde das montanhas

  triangle(0, height * 0.8, width * 0.3, height * 0.4, width * 0.6, height * 0.8);

  triangle(width * 0.4, height * 0.8, width * 0.7, height * 0.3, width, height * 0.8);

}

function drawCampo() {

  fill(124, 252, 0); // Verde grama

  rect(0, height * 0.8, width, height * 0.2);

}

function drawLinhaDoHorizonte() {

  stroke(150); // Linha cinza clara

  strokeWeight(2);

  line(0, height * 0.7, width, height * 0.7);

}

function drawPredios() {

  let numPredios = 8;

  let larguraPredio = width / (numPredios * 1.2);

  let alturaBase = height * 0.4;

  for (let i = 0; i < numPredios; i++) {

    let x = i * (larguraPredio + 10) + width * 0.1;

    let alturaPredio = random(height * 0.1, height * 0.3);

    fill(50, 50, 70); // Cinza escuro dos prédios

    rect(x, height - alturaBase - alturaPredio, larguraPredio, alturaPredio);

    // Janelas

    fill(255, 255, 0, 150); // Amarelo claro para janelas

    let numJanelasX = floor(larguraPredio / 15);

    let numJanelasY = floor(alturaPredio / 15);

    for (let j = 0; j < numJanelasX; j++) {

      for (let k = 0; k < numJanelasY; k++) {

        if (random(1) > 0.3) { // Algumas janelas acesas

          rect(x + 5 + j * 12, height - alturaBase - alturaPredio + 5 + k * 12, 8, 8);

        }

      }

    }

  }

}

function drawEstrada() {

  fill(80, 80, 80); // Cinza escuro da estrada

  rect(0, height - 120, width, 120);

  // Linhas da estrada

  stroke(255, 255, 0); // Amarelo das linhas

  strokeWeight(3);

  for (let i = 0; i < width; i += 40) {

    line(i, height - 60, i + 20, height - 60);

  }

}

function drawCarros() {

  for (let carro of carros) {

    fill(carro.cor);

    rect(carro.x, carro.y, carro.largura, carro.altura, 5); // Arredonda os cantos

    // Pneus

    fill(0);

    ellipse(carro.x + carro.largura * 0.2, carro.y + carro.altura, 10, 10);

    ellipse(carro.x + carro.largura * 0.8, carro.y + carro.altura, 10, 10);

    // Move o carro

    carro.x -= carro.velocidade;

    if (carro.x < -carro.largura) {

      carro.x = width + random(width * 0.5);

      carro.cor = color(random(0, 255), random(0, 255), random(0, 255));

      carro.velocidade = random(2, 4);

    }

  }

}

function drawPostesDeLuz() {

  fill(100, 100, 100); // Cor do poste

  noStroke();

  for (let i = 0; i < width; i += 150) {

    // Tronco do poste

    rect(i + 20, height - 200, 10, 80);

    // Luz

    fill(255, 255, 0, 180); // Amarelo claro e transparente para a luz

    ellipse(i + 25, height - 205, 15, 15);

  }

}